<title>BD-ITEC | Bangladesh IT-engineers Examination Center</title>
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('aduca/images/apple-touch-icon.png') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('aduca/images/favicon-32x32.png') }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('aduca/images/favicon-16x16.png') }}">
    <link rel="manifest" href="{{ asset('aduca/images/site.webmanifest') }}">
